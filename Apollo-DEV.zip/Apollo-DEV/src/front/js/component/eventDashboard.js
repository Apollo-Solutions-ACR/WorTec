import React from 'react';

export const Event = () => {
  return (
    <div className="dashboard-container bg-orange-500 rounded-lg p-2 text-white shadow-md flex flex-col justify-center items-center">
      <h2 className="text-2xl font-bold">Próximos Eventos</h2>
    </div>
  );
};


