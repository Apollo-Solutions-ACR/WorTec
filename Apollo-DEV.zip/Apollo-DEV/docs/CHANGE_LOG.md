# CHANGE LOG

Here we are tracking the previous and upcoming changes (roadmap), pull request this file or open an issue if you have any suggestions for the next version of the boilerplate.

## Roadmap v2.0

- [ ] Update documentation with more examples

### August 9th, 2019
- [x] Removed eralchemy from the Pipfile because its compatibility with Apply and PC computers its not clear. There is now way to create a database diagra.png anymore.
- [x] Added this changelog file to keep track of changes on the boilerplate.
- [x] Added documentation for [data validations](https://github.com/4GeeksAcademy/flask-rest-hello/blob/master/docs/DATA_VALIDATIONS.md)
- [x] Added documentation for [SQL Alchemy operations](https://github.com/4GeeksAcademy/flask-rest-hello/edit/master/docs/MYSQL.md).

### Sep 16th, 2019
- [x] Added debuging functionality
